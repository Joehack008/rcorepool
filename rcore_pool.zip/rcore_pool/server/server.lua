-- Leaked By: 5M-Leaks | 5M-Leaks | https://5m-leaks.com
AddEventHandler('rcore_pool:notification', function(serverId, message)
	TriggerClientEvent("esx:showNotification", serverId, message)
end)